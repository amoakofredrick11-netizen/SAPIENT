function handleLogin(event) {
    event.preventDefault();
    const role = document.getElementById('login-role').value;

    // Hide login container
    document.getElementById('login-container').classList.add('hidden');

    // Show correct dashboard based on role selection
    if (role === 'student') {
        document.getElementById('student-dashboard').classList.remove('hidden');
    } else if (role === 'coordinator') {
        document.getElementById('coordinator-dashboard').classList.remove('hidden');
    } else if (role === 'admin') {
        document.getElementById('admin-dashboard').classList.remove('hidden');
    }
}

function logout() {
    // Hide all dashboards
    document.getElementById('student-dashboard').classList.add('hidden');
    document.getElementById('coordinator-dashboard').classList.add('hidden');
    document.getElementById('admin-dashboard').classList.add('hidden');

    // Show login container
    document.getElementById('login-container').classList.remove('hidden');
}

function addStudent() {
    const studentName = prompt("Enter Student Full Name:");
    if (studentName) {
        const listDiv = document.getElementById('coordinator-student-list');
        if (listDiv.innerHTML.includes('No new students')) {
            listDiv.innerHTML = '';
        }
        listDiv.innerHTML += `<p>✅ Added Student: <strong>${studentName}</strong></p>`;
    }
}

function addCoordinator() {
    const coordName = prompt("Enter Coordinator Full Name:");
    if (coordName) {
        const listDiv = document.getElementById('admin-users-list');
        listDiv.innerHTML += `<p>🛡️ Added Coordinator: <strong>${coordName}</strong></p>`;
    }
}

function addStudentAdmin() {
    const studentName = prompt("Enter Student Full Name (Admin action):");
    if (studentName) {
        const listDiv = document.getElementById('admin-users-list');
        listDiv.innerHTML += `<p>👨‍🎓 Added Student: <strong>${studentName}</strong></p>`;
    }
}